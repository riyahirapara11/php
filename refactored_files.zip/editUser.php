<?php
include 'formTemplate.php';
$action = 'editUser.php';
$buttonText = 'Edit User';
$firstName = $lastName = ''; // set values dynamically
include 'formTemplate.php';
?>
