document.addEventListener('DOMContentLoaded', function () {
    const countries = {
        "India": ["Gujarat", "Maharashtra", "Tamilnadu", "Rajasthan"],
        "Canada": ["Alberta", "British Columbia", "Manitoba", "Quebec"],
        "USA": ["California", "Alaska", "Georgia"],
        "Japan": ["Hokkaido", "Fukushima", "Hiroshima"]
    };

    const countrySelect = document.getElementById('selectCountry');
    const stateSelect = document.getElementById('selectStates');

    function populateStates(selectedCountry, selectedState = '') {
        stateSelect.innerHTML = '<option value="" disabled>Select a state</option>';
        let states = countries[selectedCountry];

        if (states) {
            states.forEach(state => {
                let option = document.createElement('option');
                option.value = state;
                option.textContent = state;
                if (state === selectedState) {
                    option.selected = true;
                }
                stateSelect.appendChild(option);
            });
        }
    }

    countrySelect.addEventListener('change', function () {
        let selectedCountry = countrySelect.value;
        populateStates(selectedCountry);
        stateSelect.disabled = false;
    });

    // Initial population of states based on selected country
    const selectedCountry = "<?php echo $rows['country']; ?>";
    const selectedState = "<?php echo $rows['state']; ?>";
    populateStates(selectedCountry, selectedState);
});
