<form method="POST" action="<?= $action ?>">
    <div class="form_group">
        <label for="firstName">First name:</label>
        <input type="text" id="firstName" name="firstName" value="<?= $firstName ?>"> 
        <span class="error"><?= $firstNameErr ?></span>
    </div>
    <div class="form_group">
        <label for="lastName">Last name:</label>
        <input type="text" id="lastName" name="lastName" value="<?= $lastName ?>"> 
        <span class="error"><?= $lastNameErr ?></span>
    </div>
    <!-- More form fields here... -->
    <div class="form_group">
        <button type="submit"><?= $buttonText ?></button>
    </div>
</form>
